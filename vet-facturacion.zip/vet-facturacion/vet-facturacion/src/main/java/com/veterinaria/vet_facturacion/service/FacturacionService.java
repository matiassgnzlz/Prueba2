package com.veterinaria.vet_facturacion.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.veterinaria.vet_facturacion.model.Facturacion;
import com.veterinaria.vet_facturacion.repository.FacturacionRepository;

@Service
public class FacturacionService {
    private final FacturacionRepository facturacionRepository;
 
    public FacturacionService(FacturacionRepository facturacionRepository) {
        this.facturacionRepository = facturacionRepository;
    }
 
    // buscar
    public Facturacion buscarFacturacionModel(Long id) {
        return facturacionRepository.findById(id).get();
    }
 
    // listar todos
    public List<Facturacion> listar() {
        return facturacionRepository.findAll();
    }
 
    // listar por estado
    public List<Facturacion> listarPorEstado(String estado) {
        return facturacionRepository.findByEstado(estado);
    }
 
    // listar por rut cliente
    public List<Facturacion> listarPorRut(String rut) {
        return facturacionRepository.findByRut_cliente(rut);
    }
 
    // guardar
    public Facturacion guardar(Facturacion facturacion) {
        return facturacionRepository.save(facturacion);
    }
 
    // modificar
    public Facturacion actualizar(Long id, Facturacion facturacion) {
        Facturacion f = buscarFacturacionModel(id);
        f.setFecha_factura(facturacion.getFecha_factura());
        f.setNombre_cliente(facturacion.getNombre_cliente());
        f.setRut_cliente(facturacion.getRut_cliente());
        f.setDescripcion(facturacion.getDescripcion());
        f.setTotal(facturacion.getTotal());
        f.setEstado(facturacion.getEstado());
        return facturacionRepository.save(f);
    }
 
    // eliminar
    public void eliminar(Long id) {
        facturacionRepository.deleteById(id);
    }

}
