package com.veterinaria.vet_facturacion.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.veterinaria.vet_facturacion.model.Facturacion;

@Repository
public interface FacturacionRepository extends JpaRepository<Facturacion, Long> {
    List<Facturacion> findByEstado(String estado);
 
    List<Facturacion> findByRut_cliente(String rutCliente);
}
