package com.veterinaria.vet_facturacion.model;

 
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonManagedReference;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "facturacion")
public class Facturacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
 
    @Column(name = "fecha_factura")
    private LocalDate fecha_factura;
 
    @Column(name = "nombre_cliente")
    private String nombre_cliente;
 
    @Column(name = "rut_cliente")
    private String rut_cliente;
 
    @Column(name = "descripcion")
    private String descripcion;
 
    @Column(name = "total")
    private BigDecimal total;
 
    @Column(name = "estado")
    private String estado;
 
    @JsonManagedReference
    @OneToMany(mappedBy = "facturacion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<DetalleFactura> detalles;

}
