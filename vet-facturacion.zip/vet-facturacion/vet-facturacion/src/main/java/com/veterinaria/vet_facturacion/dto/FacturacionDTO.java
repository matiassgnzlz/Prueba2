package com.veterinaria.vet_facturacion.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.veterinaria.vet_facturacion.model.Facturacion;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FacturacionDTO {
    private Long id;
    private LocalDate fecha_factura;
    private String nombre_cliente;
    private String rut_cliente;
    private String descripcion;
    private BigDecimal total;
    private String estado;
 
    public Facturacion toModel() {
        return new Facturacion(id, fecha_factura, nombre_cliente, rut_cliente,
                descripcion, total, estado, null);
    }
 
    public static FacturacionDTO fromModel(Facturacion facturacion) {
        if (facturacion == null) return null;
 
        return new FacturacionDTO(
                facturacion.getId(),
                facturacion.getFecha_factura(),
                facturacion.getNombre_cliente(),
                facturacion.getRut_cliente(),
                facturacion.getDescripcion(),
                facturacion.getTotal(),
                facturacion.getEstado()
        );
    }

}
