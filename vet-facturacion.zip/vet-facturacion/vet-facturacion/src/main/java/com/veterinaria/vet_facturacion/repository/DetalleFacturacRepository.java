package com.veterinaria.vet_facturacion.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.veterinaria.vet_facturacion.model.DetalleFactura;

@Repository
public interface DetalleFacturacRepository extends JpaRepository <DetalleFactura, Long>{ 
    List<DetalleFactura> findByFacturacionId(Long facturacionId);
}
