package com.veterinaria.vet_facturacion.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.veterinaria.vet_facturacion.model.DetalleFactura;
import com.veterinaria.vet_facturacion.model.Facturacion;
import com.veterinaria.vet_facturacion.repository.DetalleFacturacRepository;
import com.veterinaria.vet_facturacion.repository.FacturacionRepository;

@Service
public class DetalleFacturaService {
    private final DetalleFacturacRepository detalleRepository;
    private final FacturacionRepository facturacionRepository;
 
    public DetalleFacturaService(DetalleFacturacRepository detalleRepository,
                                  FacturacionRepository facturacionRepository) {
        this.detalleRepository = detalleRepository;
        this.facturacionRepository = facturacionRepository;
    }
 
    // buscar
    public DetalleFactura buscarDetalleModel(Long id) {
        return detalleRepository.findById(id).get();
    }
 
    // listar todos
    public List<DetalleFactura> listar() {
        return detalleRepository.findAll();
    }
 
    // listar por factura
    public List<DetalleFactura> listarPorFactura(Long facturacionId) {
        return detalleRepository.findByFacturacionId(facturacionId);
    }
 
    // guardar
    public DetalleFactura guardar(DetalleFactura detalle, Long facturacionId) {
        Facturacion facturacion = facturacionRepository.findById(facturacionId).get();
        detalle.setFacturacion(facturacion);
        return detalleRepository.save(detalle);
    }
 
    // modificar
    public DetalleFactura actualizar(Long id, DetalleFactura detalle, Long facturacionId) {
        DetalleFactura d = buscarDetalleModel(id);
        Facturacion facturacion = facturacionRepository.findById(facturacionId).get();
        d.setDescripcion(detalle.getDescripcion());
        d.setCantidad(detalle.getCantidad());
        d.setPrecio_unitario(detalle.getPrecio_unitario());
        d.setSubtotal(detalle.getSubtotal());
        d.setFacturacion(facturacion);
        return detalleRepository.save(d);
    }
 
    // eliminar
    public void eliminar(Long id) {
        detalleRepository.deleteById(id);
    }

}
