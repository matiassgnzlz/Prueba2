package com.veterinaria.vet_facturacion.dto;

import java.math.BigDecimal;

import com.veterinaria.vet_facturacion.model.DetalleFactura;
import com.veterinaria.vet_facturacion.model.Facturacion;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetalleFacturaDTO {
    private Long id;
    private String descripcion;
    private Integer cantidad;
    private BigDecimal precio_unitario;
    private BigDecimal subtotal;
    private Long facturacion_id;
 
    public DetalleFactura toModel(Facturacion facturacion) {
        return new DetalleFactura(id, descripcion, cantidad, precio_unitario, subtotal, facturacion);
    }
 
    public static DetalleFacturaDTO fromModel(DetalleFactura detalle) {
        if (detalle == null) return null;
 
        return new DetalleFacturaDTO(
                detalle.getId(),
                detalle.getDescripcion(),
                detalle.getCantidad(),
                detalle.getPrecio_unitario(),
                detalle.getSubtotal(),
                detalle.getFacturacion() != null ? detalle.getFacturacion().getId() : null
        );
    }

}
