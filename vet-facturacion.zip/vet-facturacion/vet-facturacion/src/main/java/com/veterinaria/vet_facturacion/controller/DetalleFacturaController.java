package com.veterinaria.vet_facturacion.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.veterinaria.vet_facturacion.dto.DetalleFacturaDTO;
import com.veterinaria.vet_facturacion.model.DetalleFactura;
import com.veterinaria.vet_facturacion.service.DetalleFacturaService;

@RestController
@RequestMapping("api/detalles")
public class DetalleFacturaController {
    private final DetalleFacturaService detalleService;
 
    public DetalleFacturaController(DetalleFacturaService detalleService) {
        this.detalleService = detalleService;
    }
 
    // listar todos
    @GetMapping()
    public ResponseEntity<List<DetalleFacturaDTO>> getListar() {
        List<DetalleFactura> detalles = detalleService.listar();
        List<DetalleFacturaDTO> dtos = detalles.stream().map(DetalleFacturaDTO::fromModel).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
 
    // listar por factura
    @GetMapping("/factura/{facturacionId}")
    public ResponseEntity<List<DetalleFacturaDTO>> getListarPorFactura(@PathVariable Long facturacionId) {
        List<DetalleFactura> detalles = detalleService.listarPorFactura(facturacionId);
        List<DetalleFacturaDTO> dtos = detalles.stream().map(DetalleFacturaDTO::fromModel).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
 
    // buscar por id
    @GetMapping("/{id}")
    public ResponseEntity<DetalleFacturaDTO> obtenerPorId(@PathVariable Long id) {
        DetalleFactura detalle = detalleService.buscarDetalleModel(id);
        return ResponseEntity.ok(DetalleFacturaDTO.fromModel(detalle));
    }
 
    // guardar
    @PostMapping()
    public ResponseEntity<DetalleFacturaDTO> postSave(@RequestBody DetalleFacturaDTO detalleDTO) {
        DetalleFactura detalle = new DetalleFactura(null, detalleDTO.getDescripcion(),
                detalleDTO.getCantidad(), detalleDTO.getPrecio_unitario(),
                detalleDTO.getSubtotal(), null);
        DetalleFactura resultado = detalleService.guardar(detalle, detalleDTO.getFacturacion_id());
        return ResponseEntity.ok(DetalleFacturaDTO.fromModel(resultado));
    }
 
    // modificar
    @PutMapping("/modificar/{id}")
    public ResponseEntity<DetalleFacturaDTO> putModificar(@PathVariable Long id,
                                                           @RequestBody DetalleFacturaDTO detalleDTO) {
        DetalleFactura detalle = new DetalleFactura(null, detalleDTO.getDescripcion(),
                detalleDTO.getCantidad(), detalleDTO.getPrecio_unitario(),
                detalleDTO.getSubtotal(), null);
        DetalleFactura resultado = detalleService.actualizar(id, detalle, detalleDTO.getFacturacion_id());
        if (resultado != null) {
            return ResponseEntity.ok(DetalleFacturaDTO.fromModel(resultado));
        }
        return ResponseEntity.notFound().build();
    }
 
    // eliminar
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        detalleService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

}
