package com.veterinaria.vet_facturacion.controller;

import java.util.stream.Collectors;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.veterinaria.vet_facturacion.dto.FacturacionDTO;
import com.veterinaria.vet_facturacion.model.Facturacion;
import com.veterinaria.vet_facturacion.service.FacturacionService;

@RestController
@RequestMapping("api/facturaciones")
public class FacturacionController {
    private final FacturacionService facturacionService;
 
    public FacturacionController(FacturacionService facturacionService) {
        this.facturacionService = facturacionService;
    }
 
    // listar
    @GetMapping()
    public ResponseEntity<List<FacturacionDTO>> getListar() {
        List<Facturacion> facturas = facturacionService.listar();
        List<FacturacionDTO> dtos = facturas.stream().map(FacturacionDTO::fromModel).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
 
    // listar por estado
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<FacturacionDTO>> getListarPorEstado(@PathVariable String estado) {
        List<Facturacion> facturas = facturacionService.listarPorEstado(estado);
        List<FacturacionDTO> dtos = facturas.stream().map(FacturacionDTO::fromModel).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
 
    // listar por rut
    @GetMapping("/cliente/{rut}")
    public ResponseEntity<List<FacturacionDTO>> getListarPorRut(@PathVariable String rut) {
        List<Facturacion> facturas = facturacionService.listarPorRut(rut);
        List<FacturacionDTO> dtos = facturas.stream().map(FacturacionDTO::fromModel).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }
 
    // buscar por id
    @GetMapping("/{id}")
    public ResponseEntity<FacturacionDTO> obtenerPorId(@PathVariable Long id) {
        Facturacion facturacion = facturacionService.buscarFacturacionModel(id);
        return ResponseEntity.ok(FacturacionDTO.fromModel(facturacion));
    }
 
    // guardar
    @PostMapping()
    public ResponseEntity<FacturacionDTO> postSave(@RequestBody FacturacionDTO facturacionDTO) {
        Facturacion facturacion = facturacionService.guardar(facturacionDTO.toModel());
        return ResponseEntity.ok(FacturacionDTO.fromModel(facturacion));
    }
 
    // modificar
    @PutMapping("/modificar/{id}")
    public ResponseEntity<FacturacionDTO> putModificar(@PathVariable Long id,
                                                        @RequestBody FacturacionDTO facturacionDTO) {
        Facturacion resultado = facturacionService.actualizar(id, facturacionDTO.toModel());
        if (resultado != null) {
            return ResponseEntity.ok(FacturacionDTO.fromModel(resultado));
        }
        return ResponseEntity.notFound().build();
    }
 
    // eliminar
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        facturacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}

