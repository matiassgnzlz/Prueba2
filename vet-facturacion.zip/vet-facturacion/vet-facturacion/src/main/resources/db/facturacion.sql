--liquibase formatted sql
 
--changeset facturacion:1
 
CREATE TABLE facturacion (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha_factura DATE           NOT NULL,
    nombre_cliente VARCHAR(255)  NOT NULL,
    rut_cliente   VARCHAR(20)    NOT NULL,
    descripcion   VARCHAR(500),
    total         DECIMAL(10,2)  NOT NULL,
    estado        VARCHAR(50)    NOT NULL
);
 
--changeset facturacion:2
 
CREATE TABLE detalle_factura (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    descripcion    VARCHAR(255)   NOT NULL,
    cantidad       INT            NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal       DECIMAL(10,2)  NOT NULL,
    facturacion_id BIGINT         NOT NULL,
    CONSTRAINT fk_detalle_factura FOREIGN KEY (facturacion_id) REFERENCES facturacion(id)
);
 
--changeset facturacion:3
 
INSERT INTO facturacion (fecha_factura, nombre_cliente, rut_cliente, descripcion, total, estado) VALUES
('2026-05-01', 'Juan Pérez',      '12.345.678-9', 'Consulta veterinaria general',       45000.00, 'PAGADA'),
('2026-05-02', 'Ana González',    '98.765.432-1', 'Vacunación anual + desparasitación', 32000.00, 'PAGADA'),
('2026-05-03', 'Luis Martínez',   '11.222.333-4', 'Cirugía menor y medicamentos',      120000.00, 'PENDIENTE'),
('2026-05-04', 'María López',     '55.666.777-8', 'Control postoperatorio',             28000.00, 'PAGADA'),
('2026-05-05', 'Pedro Ramírez',   '44.555.666-7', 'Examen de laboratorio',              67000.00, 'PENDIENTE'),
('2026-05-06', 'Sofía Torres',    '33.444.555-6', 'Limpieza dental y revisión',         54000.00, 'PAGADA'),
('2026-05-07', 'Diego Herrera',   '22.333.444-5', 'Hospitalización 2 días',            180000.00, 'PENDIENTE'),
('2026-05-08', 'Valentina Ríos',  '77.888.999-0', 'Microchip y certificado',            15000.00, 'PAGADA'),
('2026-05-09', 'Felipe Castro',   '66.777.888-9', 'Consulta + medicamentos',            38000.00, 'ANULADA'),
('2026-05-10', 'Camila Vargas',   '99.000.111-2', 'Ecografía abdominal',                75000.00, 'PAGADA');
 
--changeset facturacion:4
 
INSERT INTO detalle_factura (descripcion, cantidad, precio_unitario, subtotal, facturacion_id) VALUES
('Consulta veterinaria',    1,  25000.00,  25000.00, 1),
('Medicamento antibiótico', 2,  10000.00,  20000.00, 1),
('Vacuna antirrábica',      1,  18000.00,  18000.00, 2),
('Desparasitante oral',     2,   7000.00,  14000.00, 2),
('Cirugía menor',           1,  90000.00,  90000.00, 3),
('Anestesia',               1,  20000.00,  20000.00, 3),
('Medicamentos postop',     1,  10000.00,  10000.00, 3),
('Control postoperatorio',  1,  28000.00,  28000.00, 4),
('Examen de sangre',        1,  40000.00,  40000.00, 5),
('Examen de orina',         1,  27000.00,  27000.00, 5);
 