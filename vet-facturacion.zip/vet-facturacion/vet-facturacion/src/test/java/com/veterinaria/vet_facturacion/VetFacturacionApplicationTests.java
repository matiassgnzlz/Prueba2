package com.veterinaria.vet_facturacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetFacturacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
