package com.veterinaria.vet_vacunacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetVacunacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
