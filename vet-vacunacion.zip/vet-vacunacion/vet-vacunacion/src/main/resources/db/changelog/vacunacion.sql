--liquibase formatted sql

--changeset vet-vacunacion:1
CREATE TABLE vacunacion (
    id BIGINT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    nombre_mascota VARCHAR(100) NOT NULL,
    especie VARCHAR(50) NOT NULL,          
    raza VARCHAR(50),                      
    nombre_dueno VARCHAR(100) NOT NULL,
    rut_dueno VARCHAR(20) NOT NULL,
    nombre_vacuna VARCHAR(100) NOT NULL,   
    fecha_vacunacion DATE NOT NULL,
    fecha_proxima_vacunacion DATE,        
    requiere_refuerzo BOOLEAN NOT NULL DEFAULT FALSE,
    dosis_numero INT,                      
    veterinario_responsable VARCHAR(100),
    observaciones VARCHAR(500)             
);

--changeset vet-vacunacion:2
-- Registro 1: perroo
INSERT INTO vacunacion (nombre_mascota, especie, raza, nombre_dueno, rut_dueno, nombre_vacuna, fecha_vacunacion, fecha_proxima_vacunacion, requiere_refuerzo, dosis_numero, veterinario_responsable, observaciones)
VALUES ('Firulais', 'Perro', 'Labrador', 'Alberto Hurtado', '11.111.111-1', 'Antirrábica', '2025-01-15', '2026-01-15', TRUE, 1, 'Dr. Pérez', 'Sin reacciones adversas');

-- Registro 2: gatop
INSERT INTO vacunacion (nombre_mascota, especie, raza, nombre_dueno, rut_dueno, nombre_vacuna, fecha_vacunacion, fecha_proxima_vacunacion, requiere_refuerzo, dosis_numero, veterinario_responsable, observaciones)
VALUES ('Michi', 'Gato', 'Siamés', 'María Ignacia', '22.222.222-2', 'Triple Felina', '2025-03-10', '2026-03-10', TRUE, 2, 'Dra. González', 'Segunda dosis anual');

-- Registro 3: perrito
INSERT INTO vacunacion (nombre_mascota, especie, raza, nombre_dueno, rut_dueno, nombre_vacuna, fecha_vacunacion, fecha_proxima_vacunacion, requiere_refuerzo, dosis_numero, veterinario_responsable, observaciones)
VALUES ('Rocky', 'Perro', 'Pastor Alemán', 'Roberto Gomez', '33.333.333-3', 'Parvovirus', '2025-06-20', NULL, FALSE, 1, 'Dr. Pérez', 'Vacuna de aplicación única, no requiere refuerzo');