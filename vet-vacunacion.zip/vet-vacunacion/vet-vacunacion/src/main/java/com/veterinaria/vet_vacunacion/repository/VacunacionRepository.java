package com.veterinaria.vet_vacunacion.repository;

import com.veterinaria.vet_vacunacion.model.Vacunacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface VacunacionRepository extends JpaRepository <Vacunacion, Long> {
    List<Vacunacion> findByRutDueno(String rutDueno);
 
    // SELECT * FROM vacunacion WHERE LOWER(nombre_mascota) = LOWER(?)
    // → Busca sin importar si está en mayúsculas o minúsculas
    List<Vacunacion> findByNombreMascotaIgnoreCase(String nombreMascota);
 
    List<Vacunacion> findByFechaProximaVacunacionBefore(LocalDate fecha);
 
    // SELECT * FROM vacunacion WHERE requiere_refuerzo = true
    // → Lista solo las vacunas que tienen refuerzo pendiente
    List<Vacunacion> findByRequiereRefuerzoTrue();
}
