package com.veterinaria.vet_vacunacion.service;

import com.veterinaria.vet_vacunacion.dto.VacunacionDTO;
import com.veterinaria.vet_vacunacion.model.Vacunacion;
import com.veterinaria.vet_vacunacion.repository.VacunacionRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class VacunacionService {

    private final VacunacionRepository repository;
        
    public Vacunacion crear(VacunacionDTO dto) {
        log.info("Registrando vacunacion para mascota: {}", dto.getNombreMascota());
 
        Vacunacion vacunacion = Vacunacion.builder()
                .nombreMascota(dto.getNombreMascota())
                .especie(dto.getEspecie())
                .raza(dto.getRaza())
                .nombreDueno(dto.getNombreDueno())
                .rutDueno(dto.getRutDueno())
                .nombreVacuna(dto.getNombreVacuna())
                .fechaVacunacion(dto.getFechaVacunacion())
                .fechaProximaVacunacion(dto.getFechaProximaVacunacion())
                .requiereRefuerzo(dto.isRequiereRefuerzo())
                .dosisNumero(dto.getDosisNumero())
                .veterinarioResponsable(dto.getVeterinarioResponsable())
                .observaciones(dto.getObservaciones())
                .build();
        return repository.save(vacunacion);
    }
 

    public List<Vacunacion> listar() {
        log.info("Listando todas las vacunaciones");
        return repository.findAll();
    }
 
    public Vacunacion obtener(Long id) {
        log.info("Buscando vacunacion con id: {}", id);
 
        // Si no existe el id, lanza excepción → el GlobalExceptionHandler la convierte en 404
        return repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("No se encontró vacunación con id: " + id));
    }
 

    public List<Vacunacion> listarPorDueno(String rutDueno) {
        log.info("Buscando vacunaciones del dueño con RUT: {}", rutDueno);
        return repository.findByRutDueno(rutDueno);
    }
 
    
    public List<Vacunacion> listarPorMascota(String nombreMascota) {
        log.info("Buscando vacunaciones de la mascota: {}", nombreMascota);
        return repository.findByNombreMascotaIgnoreCase(nombreMascota);
    }
 
    
    public List<Vacunacion> listarProximasVencidas() {
        LocalDate fechaLimite = LocalDate.now().plusDays(30);
        log.info("Buscando vacunas que vencen antes del: {}", fechaLimite);
        return repository.findByFechaProximaVacunacionBefore(fechaLimite);
    }

    
    public Vacunacion actualizar(Long id, VacunacionDTO dto) {
        log.info("Actualizando vacunacion con id: {}", id);
        Vacunacion vacunacion = obtener(id);
        vacunacion.setNombreMascota(dto.getNombreMascota());
        vacunacion.setEspecie(dto.getEspecie());
        vacunacion.setRaza(dto.getRaza());
        vacunacion.setNombreDueno(dto.getNombreDueno());
        vacunacion.setRutDueno(dto.getRutDueno());
        vacunacion.setNombreVacuna(dto.getNombreVacuna());
        vacunacion.setFechaVacunacion(dto.getFechaVacunacion());
        vacunacion.setFechaProximaVacunacion(dto.getFechaProximaVacunacion());
        vacunacion.setRequiereRefuerzo(dto.isRequiereRefuerzo());
        vacunacion.setDosisNumero(dto.getDosisNumero());
        vacunacion.setVeterinarioResponsable(dto.getVeterinarioResponsable());
        vacunacion.setObservaciones(dto.getObservaciones());
        return repository.save(vacunacion);
    }
 
   
    public void eliminar(Long id) {
        log.warn("Eliminando vacunacion con id: {}", id);
        repository.deleteById(id);
    }
}
