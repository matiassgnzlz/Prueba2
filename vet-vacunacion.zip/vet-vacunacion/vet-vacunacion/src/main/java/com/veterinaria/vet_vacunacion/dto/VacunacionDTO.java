package com.veterinaria.vet_vacunacion.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class VacunacionDTO {
    @NotBlank(message = "El nombre de la mascota es obligatorio")
    private String nombreMascota;
 
    @NotBlank(message = "La especie es obligatoria (ej: Perro, Gato)")
    private String especie;
 
    private String raza;
 
 
    @NotBlank(message = "El nombre del dueño es obligatorio")
    private String nombreDueno;
 
    @NotBlank(message = "El RUT del dueño es obligatorio")
    private String rutDueno;
 
    // --- Datos de la vacuna ---
 
    @NotBlank(message = "El nombre de la vacuna es obligatorio (ej: Antirrábica)")
    private String nombreVacuna;
 
    @NotNull(message = "La fecha de vacunación es obligatoria (formato: YYYY-MM-DD)")
    private LocalDate fechaVacunacion;
 
    //casosi o no 
    private LocalDate fechaProximaVacunacion;
 
    
    private boolean requiereRefuerzo;
 
    
    private Integer dosisNumero;
 
    private String veterinarioResponsable; // op
 
    private String observaciones; // op
}
