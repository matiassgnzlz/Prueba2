package com.veterinaria.vet_vacunacion.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "vacunacion")
public class Vacunacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(name = "nombre_mascota", nullable = false)
    private String nombreMascota;
 
    @Column(name = "especie", nullable = false)   
    private String especie;
 
    @Column(name = "raza")                        
    private String raza;
 
    // Datos del dueño 
    @Column(name = "nombre_dueno", nullable = false)
    private String nombreDueno;
 
    @Column(name = "rut_dueno", nullable = false)
    private String rutDueno;
 
    // Datos de la vacuna
    @Column(name = "nombre_vacuna", nullable = false)  
    private String nombreVacuna;
 
    @Column(name = "fecha_vacunacion", nullable = false)
    private LocalDate fechaVacunacion;
 
    // Si la vacuna requiere refuerzo, aquí va la próxima fecha
    // Si NO requiere refuerzo, este campo queda en null
    @Column(name = "fecha_proxima_vacunacion")
    private LocalDate fechaProximaVacunacion;
 
    // true  → la vacuna necesita una dosis futura
    // false → fue una vacuna de aplicación única
    @Column(name = "requiere_refuerzo", nullable = false)
    private boolean requiereRefuerzo;
 
    @Column(name = "dosis_numero")
    private Integer dosisNumero;
 
  
    @Column(name = "veterinario_responsable")
    private String veterinarioResponsable;
 
    @Column(name = "observaciones", length = 500)
    private String observaciones;
}
