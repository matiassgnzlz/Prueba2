package com.veterinaria.vet_vacunacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VetVacunacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(VetVacunacionApplication.class, args);
	}

}
