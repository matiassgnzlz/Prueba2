package com.veterinaria.vet_vacunacion.controller;

import com.veterinaria.vet_vacunacion.dto.ApiResponse;
import com.veterinaria.vet_vacunacion.dto.VacunacionDTO;
import com.veterinaria.vet_vacunacion.model.Vacunacion;
import com.veterinaria.vet_vacunacion.service.VacunacionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/vacunacion")
public class VacunacionController {
    private final VacunacionService service;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<ApiResponse<Vacunacion>> crear(@Valid @RequestBody VacunacionDTO dto) {
        Vacunacion vacunacion = service.crear(dto);
        return ResponseEntity.status(201).body(
                ApiResponse.<Vacunacion>builder()
                        .success(true)
                        .message("Vacunación registrada exitosamente")
                        .data(vacunacion)
                        .build()
        );
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<Vacunacion>>> listar() {
        return ResponseEntity.ok(
                ApiResponse.<List<Vacunacion>>builder()
                        .success(true)
                        .message("Listado de vacunaciones obtenido")
                        .data(service.listar())
                        .build()
        );
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<ApiResponse<Vacunacion>> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(
                ApiResponse.<Vacunacion>builder()
                        .success(true)
                        .message("Vacunación obtenida")
                        .data(service.obtener(id))
                        .build()
        );
    }
    
    @GetMapping("/dueno/{rut}")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<Vacunacion>>> listarPorDueno(@PathVariable String rut) {
        return ResponseEntity.ok(
                ApiResponse.<List<Vacunacion>>builder()
                        .success(true)
                        .message("Vacunaciones del dueño obtenidas")
                        .data(service.listarPorDueno(rut))
                        .build()
        );
    }

    @GetMapping("/mascota/{nombre}")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<Vacunacion>>> listarPorMascota(@PathVariable String nombre) {
        return ResponseEntity.ok(
                ApiResponse.<List<Vacunacion>>builder()
                        .success(true)
                        .message("Vacunaciones de la mascota obtenidas")
                        .data(service.listarPorMascota(nombre))
                        .build()
        );
    }

    @GetMapping("/proximas")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public ResponseEntity<ApiResponse<List<Vacunacion>>> listarProximas() {
        return ResponseEntity.ok(
                ApiResponse.<List<Vacunacion>>builder()
                        .success(true)
                        .message("Vacunaciones que vencen en los próximos 30 días")
                        .data(service.listarProximasVencidas())
                        .build()
        );
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Vacunacion>> actualizar(@PathVariable Long id,
                                                              @Valid @RequestBody VacunacionDTO dto) {
        Vacunacion vacunacion = service.actualizar(id, dto);
        return ResponseEntity.ok(
                ApiResponse.<Vacunacion>builder()
                        .success(true)
                        .message("Vacunación actualizada correctamente")
                        .data(vacunacion)
                        .build()
        );
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.ok(
                ApiResponse.<Void>builder()
                        .success(true)
                        .message("Vacunación eliminada correctamente")
                        .build()
        );
    }
}
