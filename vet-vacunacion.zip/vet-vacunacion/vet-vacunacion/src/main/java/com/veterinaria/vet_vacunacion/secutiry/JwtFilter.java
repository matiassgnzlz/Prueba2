package com.veterinaria.vet_vacunacion.secutiry;

import org.springframework.stereotype.Component;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;


import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter{
    private final JwtUtil jwtUtil;
 
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
 
        String header = request.getHeader("Authorization");
 
        
        if (header != null && header.startsWith("Bearer ")) {
 
            String token = header.substring(7);
 
            if (jwtUtil.validateToken(token)) {
 
                String username = jwtUtil.getUsername(token);
                List<String> roles = jwtUtil.getRoles(token);
 
                List<SimpleGrantedAuthority> authorities = roles.stream()
                        .map(rol -> new SimpleGrantedAuthority("ROLE_" + rol))
                        .collect(Collectors.toList());
 
                UsernamePasswordAuthenticationToken autenticacion =
                        new UsernamePasswordAuthenticationToken(username, null, authorities);
 
                SecurityContextHolder.getContext().setAuthentication(autenticacion);
            }
        }
 
        
        filterChain.doFilter(request, response);
    }
}
